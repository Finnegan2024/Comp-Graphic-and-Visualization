#include "../7-1_FinalProjectMilestones/Source/SceneManager.h"

void SceneManager::DrawFoamRoller() {
	// defining variables
	glm::vec3 scaleXYZ;
	float XrotationDegrees;
	float YrotationDegrees;
	float ZrotationDegrees;
	glm::vec3 positionXYZ;


	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(6.0f, 30.0f, 6.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = -30.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(18.0f, 2.0f, -16.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// using foam texture for foam roller
	SetShaderTexture("foam");
	// setting material for foam texure
	SetShaderMaterial("foam_roller");
	SetTextureUVScale(3.0f, 3.0f);

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
}