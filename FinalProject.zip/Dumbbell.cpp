#include "../7-1_FinalProjectMilestones/Source/SceneManager.h"

void SceneManager::DrawDumbbell() {
	// defining variables
	glm::vec3 scaleXYZ;
	float XrotationDegrees;
	float YrotationDegrees;
	float ZrotationDegrees;
	glm::vec3 positionXYZ;


	// Part 1 of dumbbell object
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.0f, 4.0f, 1.0f);

	// set the XYZ rotation for the mesh
	// rotate across x-axis 90 degrees
	// rotate across y-axis 90 degrees
	XrotationDegrees = 90.0f;
	YrotationDegrees = 90.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 4.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// setting texture material to give a more realistic appearance to the steel
	SetShaderMaterial("steel");
	// setting texture to steel texture to give off realistic dumbbell handle appearance
	SetShaderTexture("steel");
	// tiling my steell texture on the tapered cylinders to prevent any distortion, tiling 2 times horizontally and 2 times vertically
	SetTextureUVScale(2.0, 2.0);

	// draw the mesh with transformation values
	m_basicMeshes->DrawTaperedCylinderMesh();


	// part 2 of dumbbell object
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.0f, 4.0f, 1.0f);

	// set the XYZ rotation for the mesh
	// rotate across x-axis 90 degrees
	// rotate across y-axis -90 degrees
	XrotationDegrees = 90.0f;
	YrotationDegrees = -90.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-0.01f, 4.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// setting texture material to give a more realistic appearance to the steel
	SetShaderMaterial("steel");
	// setting texture to steel texture to give off realistic dumbbell handle appearance
	SetShaderTexture("steel");
	// tiling my steell texture on the tapered cylinders to prevent any distortion, tiling 2 times horizontally and 2 times vertically
	SetTextureUVScale(2.0, 2.0);

	// draw the mesh with transformation values
	m_basicMeshes->DrawTaperedCylinderMesh();


	// part three of dumbbell object
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.25f, 1.25f, 1.25f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-4.6f, 4.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// setting texture to rubber texture to give off realistic weight appearance
	SetShaderTexture("rubber");
	// setting dumbbell rubber weight material
	SetShaderMaterial("rubber");
	SetTextureUVScale(2.0, 2.0);

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();


	// part four of dumbbell object
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.25f, 1.25f, 1.25f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-4.6f, 2.75f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// setting texture to rubber texture to give off realistic weight appearance
	SetShaderTexture("rubber");
	// setting dumbbell rubber weight material
	SetShaderMaterial("rubber");
	SetTextureUVScale(2.0, 2.0);

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();


	// part five of dumbbell object
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.25f, 1.25f, 1.25f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-4.6f, 5.25f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// setting texture to rubber texture to give off realistic weight appearance
	SetShaderTexture("rubber");
	// setting dumbbell rubber weight material
	SetShaderMaterial("rubber");
	SetTextureUVScale(2.0, 2.0);

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();


	// part six of dumbbell object
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.25f, 1.25f, 1.25f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-4.6f, 4.0f, -1.25f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// setting texture to rubber texture to give off realistic weight appearance
	SetShaderTexture("rubber");
	// setting dumbbell rubber weight material
	SetShaderMaterial("rubber");
	SetTextureUVScale(2.0, 2.0);

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();


	// part seven of dumbbell object
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.25f, 1.25f, 1.25f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-4.6f, 4.0f, 1.25f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// setting texture to rubber texture to give off realistic weight appearance
	SetShaderTexture("rubber");
	// setting dumbbell rubber weight material
	SetShaderMaterial("rubber");
	SetTextureUVScale(2.0, 2.0);

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();


	// part eight of dumbbell object
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(2.5f, 1.25f, 1.25f);

	// set the XYZ rotation for the mesh
	// rotate across y-axis 90 degrees
	// rotate across z-axis 90 degrees
	XrotationDegrees = 0.0f;
	YrotationDegrees = 90.0f;
	ZrotationDegrees = 90.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-4.6f, 5.25f, 0.6f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// setting texture to rubber texture to give off realistic weight appearance
	SetShaderTexture("rubber");
	// setting dumbbell rubber weight material
	SetShaderMaterial("rubber");
	SetTextureUVScale(2.0, 2.0);

	// draw the mesh with transformation values
	m_basicMeshes->DrawPrismMesh();


	// part nine of dumbbell object
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(2.5f, 1.25f, 1.25f);

	// set the XYZ rotation for the mesh
	// rotate across y-axis 90 degrees
	// rotate across z-axis 90 degrees
	XrotationDegrees = 0.0f;
	YrotationDegrees = 90.0f;
	ZrotationDegrees = 90.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-4.6f, 5.25f, -0.6f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// setting texture to rubber texture to give off realistic weight appearance
	SetShaderTexture("rubber");
	// setting dumbbell rubber weight material
	SetShaderMaterial("rubber");
	SetTextureUVScale(2.0, 2.0);

	// draw the mesh with transformation values
	m_basicMeshes->DrawPrismMesh();


	// part ten of dumbbell object
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(2.5f, 1.25f, 1.25f);

	// set the XYZ rotation for the mesh
	// rotate across y-axis 90 degrees
	// rotate across z-axis -90 degrees
	XrotationDegrees = 0.0f;
	YrotationDegrees = 90.0f;
	ZrotationDegrees = -90.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-4.6f, 2.75f, 0.6f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// setting texture to rubber texture to give off realistic weight appearance
	SetShaderTexture("rubber");
	// setting dumbbell rubber weight material
	SetShaderMaterial("rubber");
	SetTextureUVScale(2.0, 2.0);

	// draw the mesh with transformation values
	m_basicMeshes->DrawPrismMesh();


	// part eleven of dumbbell object
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(2.5f, 1.25f, 1.25f);

	// set the XYZ rotation for the mesh
	// rotate across y-axis 90 degrees
	// rotate across z-axis -90 degrees
	XrotationDegrees = 0.0f;
	YrotationDegrees = 90.0f;
	ZrotationDegrees = -90.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-4.6f, 2.75f, -0.6f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// setting texture to rubber texture to give off realistic weight appearance
	SetShaderTexture("rubber");
	// setting dumbbell rubber weight material
	SetShaderMaterial("rubber");
	SetTextureUVScale(2.0, 2.0);

	// draw the mesh with transformation values
	m_basicMeshes->DrawPrismMesh();


	// part twelve of dumbbell object
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.25f, 1.25f, 1.25f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(4.6f, 4.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// setting texture to rubber texture to give off realistic weight appearance
	SetShaderTexture("rubber");
	// setting dumbbell rubber weight material
	SetShaderMaterial("rubber");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();


	// part thirteen of dumbbell object
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.25f, 1.25f, 1.25f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(4.6f, 5.25f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// setting texture to rubber texture to give off realistic weight appearance
	SetShaderTexture("rubber");
	// setting dumbbell rubber weight material
	SetShaderMaterial("rubber");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();


	// part fourteen of dumbbell object
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.25f, 1.25f, 1.25f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(4.6f, 2.75f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// setting texture to rubber texture to give off realistic weight appearance
	SetShaderTexture("rubber");
	// setting dumbbell rubber weight material
	SetShaderMaterial("rubber");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();


	// part fifteen of dumbbell object
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.25f, 1.25f, 1.25f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(4.6f, 4.0f, 1.25f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// setting texture to rubber texture to give off realistic weight appearance
	SetShaderTexture("rubber");
	// setting dumbbell rubber weight material
	SetShaderMaterial("rubber");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();


	// part sixteen of dumbbell object
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.25f, 1.25f, 1.25f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(4.6f, 4.0f, -1.25f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// setting texture to rubber texture to give off realistic weight appearance
	SetShaderTexture("rubber");
	// setting dumbbell rubber weight material
	SetShaderMaterial("rubber");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();


	// part seventeen of dumbbell object
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(2.5f, 1.25f, 1.25f);

	// set the XYZ rotation for the mesh
	// rotate across y-axis 90 degrees
	// rotate across z-axis -90 degrees
	XrotationDegrees = 0.0f;
	YrotationDegrees = 90.0f;
	ZrotationDegrees = -90.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(4.6f, 2.75f, -0.6f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// setting texture to rubber texture to give off realistic weight appearance
	SetShaderTexture("rubber");
	// setting dumbbell rubber weight material
	SetShaderMaterial("rubber");

	// draw the mesh with transformation values
	m_basicMeshes->DrawPrismMesh();


	// part eighteen of dumbbell object
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(2.5f, 1.25f, 1.25f);

	// set the XYZ rotation for the mesh
	// rotate across y-axis 90 degrees
	// rotate across z-axis -90 degrees
	XrotationDegrees = 0.0f;
	YrotationDegrees = 90.0f;
	ZrotationDegrees = -90.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(4.6f, 2.75f, 0.6f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// setting texture to rubber texture to give off realistic weight appearance
	SetShaderTexture("rubber");
	// setting dumbbell rubber weight material
	SetShaderMaterial("rubber");

	// draw the mesh with transformation values
	m_basicMeshes->DrawPrismMesh();


	// part nineteen of dumbbell object
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(2.5f, 1.25f, 1.25f);

	// set the XYZ rotation for the mesh
	// rotate across y-axis 90 degrees
	// rotate across z-axis 90 degrees
	XrotationDegrees = 0.0f;
	YrotationDegrees = 90.0f;
	ZrotationDegrees = 90.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(4.6f, 5.25f, -0.6f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// setting texture to rubber texture to give off realistic weight appearance
	SetShaderTexture("rubber");
	// setting dumbbell rubber weight material
	SetShaderMaterial("rubber");

	// draw the mesh with transformation values
	m_basicMeshes->DrawPrismMesh();


	// part twenty of dumbbell object
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(2.5f, 1.25f, 1.25f);

	// set the XYZ rotation for the mesh
	// rotate across y-axis 90 degrees
	// rotate across z-axis 90 degrees
	XrotationDegrees = 0.0f;
	YrotationDegrees = 90.0f;
	ZrotationDegrees = 90.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(4.6f, 5.25f, 0.6f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// setting texture to rubber texture to give off realistic weight appearance
	SetShaderTexture("rubber");
	// setting dumbbell rubber weight material
	SetShaderMaterial("rubber");

	// draw the mesh with transformation values
	m_basicMeshes->DrawPrismMesh();
	/****************************************************************/
}