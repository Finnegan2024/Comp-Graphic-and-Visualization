#include "../7-1_FinalProjectMilestones/Source/SceneManager.h"

void SceneManager::DrawWaterBottle() {
	// defining variables
	glm::vec3 scaleXYZ;
	float XrotationDegrees;
	float YrotationDegrees;
	float ZrotationDegrees;
	glm::vec3 positionXYZ;



	// drawing part of water bottle (cylinder object)
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(2.5f, 9.0f, 2.5f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-1.0f, 2.0f, -12.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// using water bottle texture
	SetShaderTexture("bottle");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();


	// drwaing part of water bottle (cylinder object)
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(2.5f, 3.0f, 2.5f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-1.0f, 11.0f, -12.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// using water bottle texture
	SetShaderTexture("bottle");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();


	// drawing part of water bottle (tapered cylinder object)
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(2.5f, 1.5f, 2.5f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-1.0f, 14.0f, -12.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// using water bottle texture
	SetShaderTexture("bottle");

	// draw the mesh with transformation values
	m_basicMeshes->DrawTaperedCylinderMesh();


	// drawing part of water bottle (cylinder object)
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(2.0f, 1.0f, 2.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-1.0f, 14.5f, -12.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// this is an internal cylinder with color black to help give water bottle a sense of depth and distinction of the bottle lid
	SetShaderColor(0.0f, 0.0f, 0.0f, 1.0f);

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();


	// drawing part of water bottle (cylinder object)
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(2.15f, 1.5f, 2.15f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-1.0f, 14.6f, -12.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// using water bottle texture
	SetShaderTexture("bottle");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();


	// drawing part of water bottle (torus object)
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(2.0f, 2.0f, 3.5f);

	// set the XYZ rotation for the mesh
	// rotate -30 degrees around y-axis to get waterbottle handle alignment correct
	XrotationDegrees = 0.0f;
	YrotationDegrees = -30.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-1.0f, 16.0f, -12.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// using water bottle texture
	SetShaderTexture("bottle");

	// draw the mesh with transformation values
	m_basicMeshes->DrawTorusMesh();
	/****************************************************************/
}