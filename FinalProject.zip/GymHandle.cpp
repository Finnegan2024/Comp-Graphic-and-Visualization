#include "../7-1_FinalProjectMilestones/Source/SceneManager.h"

void SceneManager::DrawGymHandle() {
	// defining variables
	glm::vec3 scaleXYZ;
	float XrotationDegrees;
	float YrotationDegrees;
	float ZrotationDegrees;
	glm::vec3 positionXYZ;



	// drawing part of gym handle object (tapered cylinder object)
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(3.0f, 8.0f, 1.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 90.0f;
	YrotationDegrees = 30.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(12.0f, 2.75f, 2.99f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);

	// draw the mesh with transformation values
	m_basicMeshes->DrawTaperedCylinderMesh();
	
	
	// drawing part of gym handle object (tapered cylinder object)
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(2.75f, 8.0f, 1.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 90.0f;
	YrotationDegrees = 82.5f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(14.9f, 2.75f, -0.5f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);

	// draw the mesh with transformation values
	m_basicMeshes->DrawTaperedCylinderMesh();
	

	// drawing part of gym handle object (prism object)
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(5.25f, 1.75f, 5.25f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 263.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(12.75f, 2.75f, -1.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);

	// draw the mesh with transformation values
	m_basicMeshes->DrawPrismMesh();

	
	// drawing part of gym handle object (prism object)
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(5.25f, 1.75f, 5.25f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = -33.5f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(10.9f, 2.75f, 2.3f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);

	// draw the mesh with transformation values
	m_basicMeshes->DrawPrismMesh();
	

	// drawing part of gym handle object (box object)
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(3.0f, 7.0f, 0.5f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = -33.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(12.5f, 5.5f, 0.25f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();


	// drawing part of gym handle object (cylinder object)
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.75f, 6.0f, 0.75f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(15.25f, 2.75f, 8.75f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();


	// drawing part of gym handle object (cylinder object)
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.75f, 6.0f, 0.75f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(21.5f, 2.75f, 0.5f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();


	// drawing part of gym handle object (cylinder object)
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(3.0f, 8.0f, 1.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 90.0f;
	YrotationDegrees = 30.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(12.0f, 9.0f, 2.99f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);

	// draw the mesh with transformation values
	m_basicMeshes->DrawTaperedCylinderMesh();


	// drawing part of gym handle object (cylinder object)
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(2.75f, 8.0f, 1.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 90.0f;
	YrotationDegrees = 82.5f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(14.9f, 9.0f, -0.5f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);

	// draw the mesh with transformation values
	m_basicMeshes->DrawTaperedCylinderMesh();


	// drawing part of gym handle object (prism object)
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(5.25f, 1.75f, 5.25f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 263.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(12.75f, 9.0f, -1.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);

	// draw the mesh with transformation values
	m_basicMeshes->DrawPrismMesh();


	// drawing part of gym handle object (prism object)
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(5.25f, 1.75f, 5.25f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = -33.5f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(10.9f, 9.0f, 2.3f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);

	// draw the mesh with transformation values
	m_basicMeshes->DrawPrismMesh();
}