#include "../7-1_FinalProjectMilestones/Source/SceneManager.h"

void SceneManager::DrawKettlebell() {
	// defining variables
	glm::vec3 scaleXYZ;
	float XrotationDegrees;
	float YrotationDegrees;
	float ZrotationDegrees;
	glm::vec3 positionXYZ;



	// draw part of kettlebell object (sphere object)
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(4.0f, 4.0f, 4.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-3.5f, 6.0f, 8.5f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// using kettlebell texure
	SetShaderTexture("kettlebell");
	// setting kettlebell material
	SetShaderMaterial("castiron");

	// draw the mesh with transformation values
	m_basicMeshes->DrawSphereMesh();


	// draw part of kettlebell object (torus object)
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(4.0f, 4.0f, 4.0f);

	// set the XYZ rotation for the mesh
	// rotate across y-axis -55 degrees to get kettlebell handle alignment correct
	XrotationDegrees = 0.0f;
	YrotationDegrees = -55.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-3.5f, 10.0f, 8.5f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// using kettlebell texture
	SetShaderTexture("kettlebell");
	// setting kettlebell material
	SetShaderMaterial("castiron");

	// draw the mesh with transformation values
	m_basicMeshes->DrawTorusMesh();
}